﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GKelting_Project4
{
    class Program
    {
        static void Main(string[] args)
        {

            // Prompt the user if they work hourly or have a salary
            Console.Write("Are you an 'hourly' employee or a 'salary' employee? ");
            // Read in the user input for employee type
            string userEmployeeTypeInput = Console.ReadLine();

            // Determine if the user employee type was salary by comparison and also ignoring case to avoid capitalization error
            if (string.Compare(userEmployeeTypeInput, "salary", true) == 0)
            {
                // Prompt user for their salary amount
                Console.Write("What is your annual salary? $");
                // Convert user salary input to decimal 
                decimal userSalaryInput = Convert.ToDecimal(Console.ReadLine());

                // Error check the salary amount
                if (userSalaryInput < 0)
                {
                    // Tell the user there was an invalid salary input
                    Console.WriteLine("I'm sorry, but the salary input is invalid. Please restart the Console.");
                }

                // If there was no error, compute the weekly wage
                else
                {
                    // Call method to calculate weekly wage for salary employees
                    decimal weeklyWageForSalary = CalculateWeeklyWageForSalary(userSalaryInput);
                    // Display the weekly wage to the user
                    Console.WriteLine($"Your pay per week is: {weeklyWageForSalary,0:C}");
                }
            }

            // Determine if the user employee type was hourly by comparison and also ignoring case to avoid capitalization error
            else if (string.Compare(userEmployeeTypeInput, "hourly", true) == 0)
            {
                // Prompt user for how much they make per hour
                Console.Write("How much do you make per hour? $");
                // Convert user hourly wage input to decimal
                decimal userHourlyWageInput = Convert.ToDecimal(Console.ReadLine());

                // Prompt user for how many hours they worked this week
                Console.Write("How many hours did you work this week? ");
                // Convert user hours worked input to double 
                double userHoursWorkedInput = Convert.ToDouble(Console.ReadLine());

                // Error check the amount of hours worked or hourly wage
                if (userHoursWorkedInput < 0 || userHourlyWageInput < 0)
                {
                    // Tell the user there was an invalid input for hours worked or hourly wage
                    Console.WriteLine("I'm sorry, but there was an invalid input for hours worked or hourly wage. Please restart the Console.");
                }
                // If there was no error, compute the weekly wage
                else
                {
                    // Call method to calculate weekly wage for hourly employees
                    decimal weeklyWageForHourly = CalculateWeeklyWageForHourly(userHourlyWageInput, userHoursWorkedInput);
                    // Display the weekly wage to the user
                    Console.WriteLine($"Your pay per week is: {weeklyWageForHourly,0:C}");
                }
            }

            // Error check the employee type
            else
            {
                // Tell the user the employee type is invalid
                Console.WriteLine("I'm sorry, but that was an invalid employee type. Please restart the Console.");
            }

            // Holds the output until the user presses a key
            Console.ReadKey();
        }

        // Create the method for calculating the weekly wage of a salary employee
        static decimal CalculateWeeklyWageForSalary(decimal salaryInput)
        {
            // Declare the constant weeks per year
            const double WEEKS_PER_YEAR = 52;
            // Compute the weekly wage by dividing the annual salary by 52
            decimal weeklyWageSalary = salaryInput / (decimal)WEEKS_PER_YEAR;
            // Return the weekly wage as the method’s output
            return weeklyWageSalary;
        }

        // Create the method for calculating the weekly wage of an hourly employee
        static decimal CalculateWeeklyWageForHourly(decimal hourlyWage, double hoursWorked)
        {
            // Declare the weekly wage hourly variable that will be assigned a value later
            decimal weeklyWageHourly;

            //Declare the constant overtime rate
            const double OVERTIME_RATE = 1.5;

            // Determine if the user worked less than or equal to 40 hours because overtime is not computed if so
            if (hoursWorked <= 40)
            {
                // Calculate the weekly wage 
                weeklyWageHourly = hourlyWage * (decimal)hoursWorked;
            }
            // More than 40 hours worked requires being paid for overtime
            else
            {
                // Calculate the regular pay
                decimal regularPay = 40 * hourlyWage;
                // Calculate the overtime pay
                decimal overtimePay = ((decimal)hoursWorked - 40) * (decimal)OVERTIME_RATE * hourlyWage;
                // Calculate the weekly wage
                weeklyWageHourly = regularPay + overtimePay;
            }

            // Return the weekly wage as the method’s output
            return weeklyWageHourly;
        }
    }
}
