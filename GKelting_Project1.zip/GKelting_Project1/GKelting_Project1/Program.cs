﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GKelting_Project1
{
    class Program
    {
        static void Main(string[] args)
        {
            //display INTEGER VARIABLES
            Console.WriteLine("INTEGER VARIABLES");

            //declare and set the FIRST INTEGER VARIABLE
            int firstIntegerVariable = 4;
            //display the first integer variable
            Console.WriteLine("The first integer variable is: " + firstIntegerVariable);

            //declare and set the SECOND INTEGER VARIABLE
            int secondIntegerVariable = 6;
            //display the second integer variable
            Console.WriteLine("The second integer variable is: " + secondIntegerVariable);

            //declare the SUM OF THE INTEGER VARIABLES
            int integerSum = firstIntegerVariable + secondIntegerVariable;
            //display the sum of the integer variables
            Console.WriteLine("The sum of the integers is: " + integerSum);

            //declare the DIFFERENCE OF THE INTEGER VARIABLES
            int integerDifference = firstIntegerVariable - secondIntegerVariable;
            //display the difference of the integer variables
            Console.WriteLine("The difference of the integers is: " + integerDifference);

            //declare the PRODUCT OF THE INTEGER VARIABLES
            int integerProduct = firstIntegerVariable * secondIntegerVariable;
            //display the product of the integer variables
            Console.WriteLine("The product of the integers is: " + integerProduct);

            //declare the QUOTIENT OF THE INTEGER VARIABLES
            int integerQuotient = firstIntegerVariable / secondIntegerVariable;
            //display the quotient of the integer variables
            Console.WriteLine("The quotient of the integers is: " + integerQuotient);


            //display DOUBLE VARIABLES
            Console.WriteLine("DOUBLE VARIABLES");

            //declare and set the FIRST DOUBLE VARIABLE
            double firstDoubleVariable = 2.71828;
            //display the first double variable
            Console.WriteLine("The first double variable is: " + firstDoubleVariable);

            //declare and set the SECOND DOUBLE VARIABLE
            double secondDoubleVariable = 3.14159;
            //display the second double variable
            Console.WriteLine("The second double variable is: " + secondDoubleVariable);

            //declare the SUM OF THE DOUBLE VARIABLES
            double doubleSum = firstDoubleVariable + secondDoubleVariable;
            //display the sum of the double variables
            Console.WriteLine("The sum of the integers is: " + doubleSum);

            //declare the DIFFERENCE OF THE DOUBLE VARIABLES
            double doubleDifference = firstDoubleVariable - secondDoubleVariable;
            //display the difference of the double variables
            Console.WriteLine("The difference of the integers is: " + doubleDifference);

            //declare the PRODUCT OF THE DOUBLE VARIABLES
            double doubleProduct = firstDoubleVariable * secondDoubleVariable;
            //display the product of the double variables
            Console.WriteLine("The product of the integers is: " + doubleProduct);

            //declare the QUOTIENT OF THE DOUBLE VARIABLES
            double doubleQuotient = firstDoubleVariable / secondDoubleVariable;
            //display the quotient of the double variables
            Console.WriteLine("The quotient of the integers is: " + doubleQuotient);

	        //Holds the output on the screen for the user to see until they hit a key or enter
            Console.ReadKey();

        }
    }
}
