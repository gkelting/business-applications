﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GKelting_Project3
{
    class Program
    {
        static void Main(string[] args)
        {
            // Disclaimer for max grade being 100
            Console.WriteLine("Please note that 100 is the highest achievable grade. \n");

            //  Prompt the user to enter the minimum grade level to achieve a A
            Console.Write("What is the minimum grade you would like to use for a student to achieve an A? ");
            //  Read user input and convert it to an integer
            int gradeA = Convert.ToInt32(Console.ReadLine());
            //  Thank the user for their input and repeat the value back to them
            Console.WriteLine("Thank you. The minimum grade to receive an A is now: " + gradeA + "\n");

            //  Prompt the user to enter the minimum grade level to achieve a B
            Console.Write("What is the minimum grade you would like to use for a student to achieve a B? ");
            //  Read user input and convert it to an integer
            int gradeB = Convert.ToInt32(Console.ReadLine());
            //  Thank the user for their input and repeat the value back to them
            Console.WriteLine("Thank you. The minimum grade to receive a B is now: " + gradeB + "\n");

            //  Prompt the user to enter the minimum grade level to achieve a C
            Console.Write("What is the minimum grade you would like to use for a student to achieve a C? ");
            //  Read user input and convert it to an integer
            int gradeC = Convert.ToInt32(Console.ReadLine());
            //  Thank the user for their input and repeat the value back to them
            Console.WriteLine("Thank you. The minimum grade to receive a C is now: " + gradeC + "\n");

            //  Prompt the user to enter the minimum grade level to achieve a D
            Console.Write("What is the minimum grade you would like to use for a student to achieve a D? ");
            //  Read user input and convert it to an integer
            int gradeD = Convert.ToInt32(Console.ReadLine());
            //  Thank the user for their input and repeat the value back to them
            Console.WriteLine("Thank you. The minimum grade to receive a D is now: " + gradeD + "\n");

            //  Prompt the user to enter a student's grade
            Console.Write("Please enter a student's grade: ");
            //  Read user input and convert it to an integer
            int studentGrade = Convert.ToInt32(Console.ReadLine());

            //  Extra space between prompts
            Console.WriteLine();

            //  Series of if statements to determine student's grade based off user input

            //  User error disclaimer because 100 is the maximum grade and negative grades are not allowed
            if (studentGrade > 100 || studentGrade < 0)
            {
                //  Tell the user the inputted grade is invalid
                Console.WriteLine("I'm sorry, but that is an invalid grade. Please restart the console.");
            }
            //  If the user input for the student's grade is greater than the minimum level input for A, 
            //  the student receives an A
            else if (studentGrade >= gradeA)
            {
                //  Tell the user the student received an A
                Console.WriteLine("The student received an A.");
            }
            //  If the user input for the student's grade is greater than the minimum level input for B 
            //  but less than that of A, the student receives a B
            else if (studentGrade >= gradeB)
            {
                //  Tell the user the student received a B
                Console.WriteLine("The student received a B.");
            }
            //  If the user input for the student's grade is greater than the minimum level input for C 
            //  but less than that of B, the student receives a C
            else if (studentGrade >= gradeC)
            {
                //  Tell the user the student received a C
                Console.WriteLine("The student received a C.");
            }
            //  If the user input for the student's grade is greater than the minimum level input for D 
            //  but less than that of C, the student receives a D
            else if (studentGrade >= gradeD)
            {
                //  Tell the user the student received a D
                Console.WriteLine("The student received a D.");
            }
            //  If the user input for the student's grade is less than the minimum level input for D,
            //  the student receives an F
            else
            {
                //  Tell the user the student received an F
                Console.WriteLine("The student received an F.");
            }

            //  Holds the output on the screen until the user presses a key.
            Console.ReadKey();
        }
    }
}
