﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GKelting_Project5
{
    class Program
    {
        //  Defines a list of strings to hold the car's make and model
        static List<string> carMakeAndModelList = new List<string>();
        //  Defines a list of integers to hold the car's year
        static List<int> carYearList = new List<int>();
        //  Defines a list of integers to hold the car's mileage
        static List<int> carMileageList = new List<int>();
        //  Defines a list of integers to hold the how many miles per gallon the car gets
        static List<int> carMilesPerGallonList = new List<int>();
        //  Defines a list of booleans that when true mean the car is rented and when false means the car is available
        static List<bool> isRented = new List<bool>();

        static void Main(string[] args)
        {
            //  Greets the user to Rent-A-Wreck
            Console.WriteLine("WELCOME TO RENT-A-WRECK!");
            //  A do-while loop to display the menu options to the user until they want to exit the console
            do
            {
                //  Displays the menu defined as a method to the user
                DisplayMenu();
                //  Initializes the menu choice the user will make
                int userMenuChoice;
                //  If the user's menu choice was valid this code will run. 
                //  In order for the menu choice to be valid, it has to be able to be converted into an integer and be between 1 and 5
                if (int.TryParse(Console.ReadLine(), out userMenuChoice) && userMenuChoice >= 0 && userMenuChoice < 6)
                {
                    //  Try attempts do the defined methods in the switch statement
                    //  Prevents the program from crashing when an input error occurs
                    try
                    {
                        //  Using the user's menu choice, the switch statement will use the respective method the menu option pertains to
                        switch (userMenuChoice)
                        {
                            //  When the user's menu choice is 1, the AddCarToInventory method will run
                            case 1:
                                //  Method that allows the user to add a car to the inventory
                                AddCarToInventory();
                                //  Case 1 is complete and is separate from the following cases
                                break;
                            //  When the user's menu choice is 2, the RentACar method will run
                            case 2:
                                //  Method that allows the user to rent an available car
                                RentACar();
                                //  Case 2 is complete and is separate from the following cases
                                break;
                            //  When the user's menu choice is 3, the ReturnACar method will run
                            case 3:
                                //  Method that allows the user to return a rented car
                                ReturnACar();
                                //  Case 3 is complete and is separate from the following cases
                                break;
                            //  When the user's menu choice is 4, the DeleteACar method will run
                            case 4:
                                //  Method that allows the user to delete an unrented car from the inventory
                                DeleteACar();
                                //  Case 4 is complete and is separate from the following cases
                                break;
                            //  When the user's menu choice is 5, the console will be exited
                            case 5:
                                //  Exits the console without throwing an error
                                Environment.Exit(0);
                                //  Case 5 is complete and is the final case
                                break;
                        }
                    }
                    //  Catch grabs the error from any of the methods defined above and presents it to the user. 
                    //  Prevents the program from crashing when an input error occurs
                    catch (Exception ex)
                    {
                        //  Displays the pertinent error to the user
                        Console.WriteLine(ex.Message);
                    }
                }
                //  Runs if the user's menu choice was invalid
                else
                {
                    //  Displays the menu choice error to the user
                    Console.WriteLine("I'm sorry, but you made an invalid selection. The menu choice must be a whole number between 1 and 5.\nPlease try again.");
                }
            //  Loop will continue to present the menu to the user until the user exits the console via menu option 5
            } while (true); 
        }

        //  Method that defines how the menu is displayed
        static void DisplayMenu()
        {
            //  Asks the user for their desired menu option
            Console.WriteLine("\nWhat would you like to do?");
            //  Displays the menu options to the user
            //  Option 1 is to add a car to the inventory
            Console.WriteLine("\n 1. Add a wreck. " +
                //  Option 2 is to rent an available car
                "\n 2. Rent a wreck. " +
                //  Option 3 is to return a rented car
                "\n 3. Return a wreck. " +
                //  Option 4 is to delete an unrented car from the inventory
                "\n 4. Retire a wreck. " +
                //  Option 5 is to exit the console window
                "\n 5. Exit the console.\n");
        }

        //  Method that allows the user to add a car to the inventory
        static void AddCarToInventory()
        {
            //  Reaffirm to the user what menu option they have selected
            Console.WriteLine("\nYou have selected to add a wreck to the inventory.\n");
            //  Ask the user for the make and model of the car
            Console.Write("What is the make and model of the car? ");
            //  Read in the user response and save it as a string for later
            string carMakeAndModel = Console.ReadLine();
            //  Throws and error if the car make and model are is an empty string
            //      https://stackoverflow.com/questions/12551567/empty-user-input-exception-c-sharp
            if (carMakeAndModel == String.Empty)
            {
                //  Tell the user that car make and model can not be blank
                Console.WriteLine("\nI'm sorry, but that entry was invalid. The car make and model cannot be blank.");
                //  Create the error message for the try-catch statement in the main method
                throw new Exception("INPUT ERROR: Car Make and Model.");
            }

            //  Ask the user for the year of the car
            Console.Write("What is the year of the car? ");
            //  Initialize the variable for the car year
            int carYear;
            //  Will run if the car year is valid
            //  Determines if the user entry is able to be converted to an integer and if the car year is between 1908 and 2020
            //  Assigns the year to the variable carYear
            if (int.TryParse(Console.ReadLine(), out carYear) && carYear >= 1908 && carYear < 2020) { }
            //  Throws an error if the car year is invalid
            else
            {
                //  Tell the user the car year is invalid and must be between 1908 and 2019
                Console.WriteLine("\nI'm sorry, but the car's year must be between 1908 and 2019 (the most recently available model of car)."); //MAKE IT GO BACK TO THE MENU
                //  Create the error message for the try-catch statement in the main method
                throw new Exception("INPUT ERROR: Car Year.");
            }

            //  Ask the user for the mileage on the car
            Console.Write("How many miles are on the car? ");
            //  Initialize the variable for the car mileage
            int carMileage;
            //  Will run if the car mileage is valid
            //  Determine if the user entry is able to be converted to an integer and if the car mileage is nonnegative
            //  Assigns the mileage to the carMileage
            if (int.TryParse(Console.ReadLine(), out carMileage) && carMileage >= 0) { }
            //  Throws an error if the car mileage is invalid
            else
            {
                //  Tell the user the car mileage is invalid and must be a nonnegative whole number
                Console.WriteLine("\nI'm sorry, but the car's mileage must be a nonnegative whole number.");
                //  Create the error message for the try-catch statement in the main method
                throw new Exception("INPUT ERROR: Car Mileage.");
            }

            //  Ask the user how many miles per gallon the car gets
            Console.Write("How many miles per gallon does the car get? ");
            //  Initialize the variable for car miles per gallon
            int carMilesPerGallon;
            //  Will run if the car MPG is valid
            //  Determine if the user entry is able to be converted to an integer and if the MPG is nonnegative
            //  Assigns the the mileage to the carMilesPerGallon
            if (int.TryParse(Console.ReadLine(), out carMilesPerGallon) && carMilesPerGallon >= 0) { }
            //  Throws an error is the car MPG is invalid
            else
            {
                //  Tell the user the car MPG is invalid and must be a nonnegative whole number
                Console.WriteLine("\nI'm sorry, but the car's miles per gallon must be a nonnegative whole number.");
                //  Create the error message for the try-catch statement in the main method
                throw new Exception("INPUT ERROR: Car Miles Per Gallon.");
            }

            //  Append the new information to the inventory if all of the information is valid
            //  Append the new car make and model to the carMakeAndModelList
            carMakeAndModelList.Add(carMakeAndModel);
            //  Append the new car year to the carYearList
            carYearList.Add(carYear);
            //  Append the new car mileage to the carMileageList
            carMileageList.Add(carMileage);
            //  Append the new car MPG to the carMilesPerGallonList
            carMilesPerGallonList.Add(carMilesPerGallon);
            //  Append the rent status to the isRented list (brand new is unrented so the status is false)
            isRented.Add(false);
            //  Thank the user for adding the car to the inventory
            Console.WriteLine($"\nThank you! You have added a {carYear} {carMakeAndModel} to the inventory.");
        }

        //  Method that allows the user to rent an available car
        static void RentACar()
        {
            //  Reaffirm to the user what menu option they have selected
            Console.WriteLine("\nYou have selected to rent a wreck.\n");
            //  If the isRented list is empty or all of the cars are rented, there are no available cars to rent
            //      https://stackoverflow.com/questions/18867180/check-if-list-is-empty-in-c-sharp
            //      https://stackoverflow.com/questions/5307172/check-if-all-items-are-the-same-in-a-list
            if (!isRented.Any() || isRented.All(car => car == true))
            {
                //  Tell the user that there are no available cars to rent
                Console.WriteLine("I'm sorry but there are no cars available to rent.\n");
            }
            //  If the isRented list is NOT empty or at least one car has not been rented, then there are available cars to rent
            else
            {
                //  Uses the DisplayCarInventory method with false passed as a parameter
                //  Will display all inventory that has not been rented
                DisplayCarInventory(false);
                //  Ask the user which car they would like to rent
                Console.Write("\nPlease select the car you would like to rent by entering the index number: ");
                //  Initializes the variable for the car the user wants to rent
                int carWantingToRent;
                //  Will run if the car index that the user wants to rent is valid
                //  Determines if the user entry is able to be converted to an integer
                if (int.TryParse(Console.ReadLine(), out carWantingToRent)
                    //  Determines if the user entry is nonnegative
                    && carWantingToRent >= 0
                    //  Determines if the user entry is within the proper range of inventory indices
                    && carWantingToRent < carMakeAndModelList.Count
                    //  Determines if the user entry is a valid index for a car that is rented and available to rent
                    && isRented[carWantingToRent] == false)
                {
                   //   Changes the isRented information of the car to true
                   isRented[carWantingToRent] = true;
                    //  Thank the user for renting the car
                   Console.WriteLine($"Thank you! You have rented the {carYearList[carWantingToRent]} {carMakeAndModelList[carWantingToRent]}.");
                }
                //  Throws an error if the car index the user wanted was invalid
                else
                {
                    //  Tell the user the index they chose was invalid
                    //  The index must be a nonnegative whole number for a car that is available to rent
                    Console.WriteLine("\nI'm sorry, but that is an invalid index number. The index number must be a nonnegative whole number for a car that is available to rent.");
                    //  Create the error message for the try-catch statement in the main method
                    throw new Exception("INPUT ERROR: Index value for car wanting to rent.");
                }
            }
        }

        //  Method that allows the user to return a rented a car
        static void ReturnACar()
        {
            //  Reaffirm to the user what menu option they have selected
            Console.WriteLine("\nYou have selected to return a wreck.\n");
            //  If the isRented list is empty or all of the cars are unrented, there are no available cars to return
            if (!isRented.Any() || isRented.All(car => car == false))
            {
                //  Tell the user there are no available cars to return
                Console.WriteLine("I'm sorry but there are no cars available to return.\n");
            }
            //  If the isRented list is NOT empty or at least one car has been rented, then there are available cars to return
            else
            {
                //  Uses the DisplayCarInventory method with true passed as a parameter
                //  Will display all inventory that has been rented
                DisplayCarInventory(true);
                //  Ask the user which car they would like to return
                Console.Write("\nPlease select the car you would like to return by entering the index number: ");
                //  Initializes the variable for the car the user wants to return
                int carWantingToReturn;
                //  Will run if the car index that the user wants to return is valid
                //  Determines if the user entry is able to be converted to an integer
                if (int.TryParse(Console.ReadLine(), out carWantingToReturn)
                    //  Determines if the user entry is nonnegative
                    && carWantingToReturn >= 0
                    //  Determines if the user entry is within the proper range of inventory indices
                    && carWantingToReturn < carMakeAndModelList.Count
                    //  Determines if the user entry is a valid index for a car that is rented and available to return
                    && isRented[carWantingToReturn] == true)
                {
                    //  Askes the user for the new mileage on the car
                    Console.WriteLine("What is the new mileage on the car?");
                    //  Initializes the variable for the new car mileage
                    int carNewMileage;
                    //  Will run if the new car mileage is valid
                    //  The new car mileage has to be able to be converted to an integer and also be greater than or equal to the previous car mileage
                    if (int.TryParse(Console.ReadLine(), out carNewMileage) && carNewMileage >= carMileageList[carWantingToReturn])
                    {
                        //  Defines the 0.50 cost per mile fee
                        const decimal PER_MILE_FEE = 0.5m;
                        //  Determines the miles driven by subtracting the old mileage from the new mileage
                        int milesDriven = carNewMileage - carMileageList[carWantingToReturn];
                        //  Determines the rental cost of the car by adding the per mile fee to the $10 base fee
                        decimal carRentalCost = 10 + (PER_MILE_FEE*(decimal)milesDriven);
                        //  Changes car mileage in the car milage list to the new mileage
                        carMileageList[carWantingToReturn] = carNewMileage;
                        //  Changes the car from being rented (true) to unrented (false)
                        isRented[carWantingToReturn] = false;
                        //  Thank the user for returning the car
                        Console.WriteLine($"\nThank you! You have returned the {carYearList[carWantingToReturn]} {carMakeAndModelList[carWantingToReturn]}.");
                        //  Display to the user the total cost for their car rental
                        Console.WriteLine($"Your total for the rental is: {carRentalCost,10:C}\n");
                    }
                    //  Throws an error if the new milage is invalid
                    else
                    {   //  Tell the user the new mileage is invalid
                        //  The new mileage must be greater than or equal to the previous mileage on the car
                        Console.WriteLine("\nI'm sorry, but that is an invalid mileage number. The mileage must be greater than or equal to the previous mileage on the car.");
                        //  Create the error message for the trt-catch statement in the main method
                        throw new Exception("INPUT ERROR. Mileage error for car wanting to return.");
                    }
                }
                //  Throws an error if the car index the user wanted to return is invalid
                else
                {
                    //  Tell the user that the car index they chose was invalid
                    //  The index must be a nonnegative whole number for a car that is available to return
                    Console.WriteLine("\nI'm sorry, but that is an invalid index number. The index number must be a nonnegative whole number for a car that is available to return.");
                    //  Create the error message for the try-catch statement in the main method
                    throw new Exception("INPUT ERROR: Index value for car wanting to return.");
                }
            }
        }

        //  Method that allows the user to delete an unrented car from the inventory
        static void DeleteACar()
        {
            //  Reaffirm to the user what menu option they have selected
            Console.WriteLine("\nYou have selected to retire a wreck.\n");
            //  If the isRented list is empty or all of the cars are rented, there are no available cars to delete
            if (!isRented.Any() || isRented.All(car => car == true))
            {
                //  Tell the user there are no available cars to delete
                Console.WriteLine("I'm sorry but there are no cars available to retire.\n");
            }
            //  If the isRented list is NOT empty or at least one car has not been rented, then there are available cars to delete
            else
            {
                //  Uses the DisplayCarInventory method with false passed as a parameter
                //  Will display all inventory that has NOT been rented
                DisplayCarInventory(false);
                //  Ask the user which car they would like to delete
                Console.Write("\nPlease select the car you would like to retire by entering the index number: ");
                //  Initializes the variable for the car the user wants to retire
                int carWantingToRetire;
                //  Will run if the car index that the user wants to retire is valid
                //  Determines if the user entry is able to be converted to an integer
                if (int.TryParse(Console.ReadLine(), out carWantingToRetire)
                    //  Determines if the user entry is nonnegative
                    && carWantingToRetire >= 0
                    //  Determines if the user entry is within the proper range of inventory indices
                    && carWantingToRetire < carMakeAndModelList.Count
                    //  Determines if the user entry is a valid index for a car that is unrented and available to delete
                    && isRented[carWantingToRetire] == false)
                {
                    // Thank the user for their selection of wanting to retire the car they chose
                    Console.WriteLine($"Thank you! You have retired the {carYearList[carWantingToRetire]} {carMakeAndModelList[carWantingToRetire]}.\n");
                    //  Remove the car information from each list
                    //  Deletes the car entry from the car make and model list
                    carMakeAndModelList.RemoveAt(carWantingToRetire);
                    //  Deletes the car entry from the car year list
                    carYearList.RemoveAt(carWantingToRetire);
                    //  Deletes the car entry from the car mileage list
                    carMileageList.RemoveAt(carWantingToRetire);
                    //  Deletes the car entry from the car miles per gallon list
                    carMilesPerGallonList.RemoveAt(carWantingToRetire);
                    //  Deletes the car entry from the is rented list
                    isRented.RemoveAt(carWantingToRetire);
                }
                //  Throws an error if the car index that the user wants to retire is invalid
                else
                {
                    //  Tell the user the index number was invalid
                    //  The index number must be a nonnegative whole number for a car that is unrented
                    Console.WriteLine("\nI'm sorry, but that is an invalid index number. The index number must be a nonnegative whole number for a car that is available to retire.");
                    //  Create the error message for the try-catch statement in the main method
                    throw new Exception("INPUT ERROR: Index value for car wanting to retire.");
                }
            }

        }
        
        //  Method that displays the car inventory that accepts if the user needs rented or unrented cars displayed as a parameter
        static void DisplayCarInventory(bool isCarRented)
        {
            //  Displays the "column titles" for each part of the inventory to the user
            //  The first "column" is the car's index
            Console.WriteLine($"Index" +
                    //  The second "column" is the car's year
                    $"\tYear" +
                    //  The third "column" is the car's make and model
                    $"\tMake and Model" +
                    //  The fourth "column" is the car's mileage
                    $"\t\tMileage" +
                    //  The fifth "column" is the how many miles per gallon the car gets
                    $"\t\tMPG");
            //  For-loop that goes through each car in the inventory
            for (int currentCar = 0; currentCar < carMakeAndModelList.Count; currentCar++)
            {
                //  Dependent on if the user needs unrented or rented cars displayed
                //  When isCarRented is false, all unrented cars in the inventory will be displayed
                //  When isCarRented is true, all rented cars in the inventory will be displayed
                if (isRented[currentCar] == isCarRented)
                {
                    //  Displays the car information in accordance to the "column titles" labeled previously
                    //  The first element displayed is the index of the car the for-loop is at that matched the isCarRented parameter
                    Console.WriteLine($"{currentCar}" +
                        //  The second element is the year of the car at the index
                        $"\t{carYearList[currentCar]}" +
                        //  The third element is the make and model of the car at the index
                        $"\t{carMakeAndModelList[currentCar]}" +
                        //  The fourth element is the milage of the car at the index
                        $"\t\t{carMileageList[currentCar]}" +
                        //  The fifth element is the miles per gallon of the car at the index
                        $"\t\t{carMilesPerGallonList[currentCar]}");
                }
            }
        }
    }
}
