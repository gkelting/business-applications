﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GKelting_Project2
{
    class Program
    {
        static void Main(string[] args)
        {
            // GRADES

            // Prompt the user to submit the first grade
            Console.Write("What is the first whole number grade you would like to use? ");
            // Read in user input
            string userGrade1 = Console.ReadLine();
            // Convert the user input from a string into an integer
            int grade1 = Convert.ToInt32(userGrade1);
            // Display the user input back to the user
            Console.WriteLine("Thank you. The first grade you chose was: " + grade1);
            // Extra space between prompts
            Console.WriteLine("\n");

            // Prompt the user to submit the second grade
            Console.Write("What is the second whole number grade you would like to use? ");
            // Read in user input
            string userGrade2 = Console.ReadLine();
            // Convert the user input from a string into an integer
            int grade2 = Convert.ToInt32(userGrade2);
            // Display the user input back to the user
            Console.WriteLine("Thank you. The second grade you chose was: " + grade2);
            // Extra space between prompts
            Console.WriteLine("\n");

            // Prompt the user to submit the third grade
            Console.Write("What is the third whole number grade you would like to use? ");
            // Read in user input
            string userGrade3 = Console.ReadLine();
            // Convert the user input from a string into an integer
            int grade3 = Convert.ToInt32(userGrade3);
            // Display the user input back to the user
            Console.WriteLine("Thank you. The third grade you chose was: " + grade3);
            // Extra space between prompts
            Console.WriteLine("\n");

            // AVERAGE OF GRADES

            // Compute average of the inputted grades
            // Convert integer grades to doubles because the average will be a double (most likely)
            double meanOfGrades = (double)(grade1 + grade2 + grade3) / 3;
            // Display the average of the inputted grades to the user to 2 decimal places
            Console.WriteLine($"The average of the grades inputted is: {meanOfGrades, 5:F2}");

            // Holds the output on the screen until the user presses a key
            Console.ReadKey();

        }
    }
}
